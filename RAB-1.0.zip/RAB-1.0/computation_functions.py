import allel
import math
import numpy
import sys
import numpy.linalg as la

# Description:
#   This function reads a VCF (Variant Call Format) file and creates a dictionary mapping chromosome numbers to their positions.
#   It also determines whether chromosome names in the VCF file are prefixed with 'chr' and adjusts accordingly.
# Accepts:
#   str file: Path to the VCF file used to extract chromosome names and positions.
# Returns:
#   dict chrom_dict: A dictionary where keys are chromosome numbers (as strings) and values are arrays of positions.
#   bool: A boolean flag indicating whether the chromosome names in the VCF file are prefixed with 'chr'.
def chrom_dict(vcf_file):
    # Read the VCF file and extract a list of chromosome names from the 'variants/CHROM' field
    callset = allel.read_vcf(vcf_file, fields=['variants/CHROM', 'variants/POS', 'samples'])
    # Determine whether the 'chr' prefix is used in the chromosome names
    prefix = 'chr' if 'chr' in callset['variants/CHROM'][0] else ''
    # Initialize an empty dictionary to store the mapping of chromosomes to positions
    refdict = {}

    # Iterate over each unique chromosome name
    for chrom in set(callset['variants/CHROM']):
        # Adjust chromosome names if necessary
        chrom_adj = chrom.replace(prefix, '')
        # Get indices where chromosome names match
        indices = callset['variants/CHROM'] == chrom
        # Map adjusted chromosome names to positions
        refdict[chrom_adj] = callset['variants/POS'][indices]

    # Return the chromosome dictionary and a boolean indicating the use of 'chr' prefix
    return refdict, bool(prefix), callset['samples']


# Description for process_site_file:
#   Processes a site file and populates lists with positions and a set with chromosome numbers.
# Accepts:
#   str file: The site file path to be processed.
#   dict refdict: Reference dictionary mapping chromosome numbers to positions.
#   dict pos_dict: Dict to be populated with keys being chromosomes and values being list of genomic
#   positions
def process_site_file(file, refdict, pos_dict):
    with open(file) as infile:
        for line in infile:
            chrom, pos = line.split()[:2]
            pos = int(pos)

            #Check if chromosome in VCF file
            if chrom in refdict:
                if pos in refdict[chrom]:
                    # Initialize the list if chrom is not yet in pos_dict
                    if chrom not in pos_dict:
                        pos_dict[chrom] = []
                    pos_dict[chrom].append(pos)
                else:
                    print(f'Position {pos} not found in VCF file for chromosome {chrom}')
                    SystemExit
            else:
                print(f'Chromosome {chrom} not found in VCF file')
                SystemExit


# Description for process_population_file:
#   Processes a population file and populates a list with valid population samples.
# Accepts:
#   str file: The population file path to be processed.
#   array samples: Array of sample identifiers from the VCF file.
#   list pop_lst: List to be populated with valid population samples.
def process_population_file(file, samples, pop_lst):
    with open(file) as infile:
        for line in infile:
            sample_id = line.split()[0]
            if sample_id in samples:
                pop_lst.append(sample_id)
            else:
              print(f'Sample: {sample_id} not found in VCF file')


# Description:
#   This function reads kinship data from files and constructs a kinship matrix.
#   Optionally, it can focus on a subset of individuals if ids_of_interest is provided.
# Accepts:
#   str idfile: Path to the file containing individual IDs.
#   str kingfile: Path to the file containing kinship data.
#   list ids_of_interest: Optional list of specific individual IDs to focus on.
# Returns:
#   list ids: List of individual IDs read from idfile.
#   ndarray kin: Numpy array representing the kinship matrix.
def kin_matrix(idfile, kingfile, ids_of_interest=None):
    # Read IDs from the ID file, skipping the first line (label)
    with open(idfile) as f:
        ids = [line.strip() for line in f][1:]
    # Initialize an empty kinship matrix
    kin = numpy.empty((len(ids), len(ids)))

    # Populate the kinship matrix from the KING file
    with open(kingfile) as f:
        for counter, line in enumerate(f):
            kin[counter] = [max(0.0, float(x.strip())) for x in line.split('\t')]

    if not ids_of_interest:
        return ids, kin
    
    # Convert ids_of_interest to a set for efficient lookup
    ids_of_interest_set = set(ids_of_interest)
    ids_set = set(ids)
    # Check for missing IDs and handle errors
    missing_ids = ids_of_interest_set - ids_set

    if missing_ids:
        print(f"The following individuals from POP file input were not found in KING ID file: {', '.join(missing_ids)}")
        raise sys.exit()
    
    # Efficient extraction of the subset of the kinship matrix
    indices_of_interest = [ids.index(i) for i in ids_of_interest]
    subset_kin = kin[numpy.ix_(indices_of_interest, indices_of_interest)]

    return ids_of_interest, subset_kin


# Description:
#   Computes allele frequencies for a given set of chromosomes and subpopulations. 
#   Uses the BLUE method if kinship matrix files are provided, otherwise uses direct counting.
# Accepts:
#   dict pos_dict: Dictionary of sites for computation.
#   list subpop: List of subpopulation sample identifiers.
#   str idfile: Path to the file containing individual IDs for kinship matrix.
#   str kingfile: Path to the file containing kinship data.
#   int indicator: Flag indicating whether chromosome names have 'chr' prefix (1) or not (0).
#   str vcf_file: Path to the VCF file used for reading genotypes.
# Returns:
#   dict af_arr: dict of arrays, each representing allele frequencies for a chromosome (keys are 
#   chromosomes and values are arrays of allele frequencies at each site).
def af_arr(pos_dict, subpop, idfile, kingfile, prefix, vcf_file):
    af_dict = {}
    kintest = idfile and kingfile  # Check if kinship matrix files are provided
    
    # If kinship matrix is provided, pre-calculate values needed for BLUE method
    if kintest:
        # Obtain the kinship matrix and individual IDs
        ids, kin = kin_matrix(idfile, kingfile, subpop)
        # Invert the kinship matrix for later calculations
        kin_inv = la.inv(kin)
        # Create a vector of ones for matrix operations
        ones_vector = numpy.ones((kin.shape[0], 1))
        # Sum the inverted kinship matrix across rows
        num_sum = kin_inv.sum(axis=0)
        # Calculate the denominator used in BLUE estimation
        denominator = ones_vector.T @ kin_inv @ ones_vector
        # Map subpopulation samples to their indices in the kinship matrix
        new_indices = [ids.index(item) for item in subpop] if subpop != ids else []
 
    # Iterate over each chromosome in the provided list
    for chrom in pos_dict:
        # Read genotype data for the specified region and subpopulation
        garr = allel.GenotypeArray(allel.read_vcf(vcf_file, region=chrom, samples=subpop)['calldata/GT'])

        # Compute allele frequencies using the BLUE method or direct counting
        if kintest:
            # If necessary, reorder the genotypes to match the order in the kinship matrix
            if new_indices:
                garr = garr[:, new_indices]
            # Convert genotype data to allele counts (n_alt)
            genotypes = garr.to_n_alt()
            # Apply the BLUE formula to compute weighted genotype frequencies
            weighted_gts = num_sum * (genotypes / 2)
            # Calculate the numerator for each locus
            numerator = weighted_gts.sum(axis=1)
            # Compute the allele frequencies using the BLUE method
            p_tild_all_loci = numerator / denominator
            # Append the resulting allele frequencies to the array
            af_dict[chrom] = p_tild_all_loci
        else:
            # Directly count alleles and calculate frequencies for the subpopulation
            garr_af = (garr.count_alleles() / ((len(garr[0, 0])) * (len(subpop))))[:, 1:]
            # Append the calculated allele frequencies to the array
            af_dict[chrom] = garr_af

    # Return the array of allele frequencies for each chromosome as a dictionary
    return af_dict


# Description:
#   This function takes allele frequency data and aligns it with the chromosome positions.
#   It ensures that the allele frequencies are in the same order as the positions in chrom_dict.
#   The function transforms the allele frequency data from dictionaries to numpy arrays for vectorized operations.
# Accepts:
#   dict af_dict: A dictionary of allele frequency data: keys - chromsomes and values - array of frequencies.
#   dict refdict: A dictionary mapping reference chromosomes to lists of positions.
# Returns:
#   dict aligned_dict: A dictionary where each key is a chromosome, and each value is a numpy array of aligned allele frequencies.
def align_af_arrays(af_dict, refdict):
    aligned_dict = {}
    for chrom, af_array in af_dict.items():
        aligned_dict[chrom] = {}
        # Create a dictionary for this chromosome
        chrom_af_dict = {}
        for pos, af in zip(refdict[chrom], af_array):
            chrom_af_dict[pos] = af[0]
        aligned_dict[chrom] = chrom_af_dict

    return aligned_dict


#Description:
#   This function computes the sum of products of allele frequencies from two populations (primary and secondary) at specific sites.
#   It utilizes vectorized operations for efficient computation. The function also includes error handling to manage any site alignment issues 
#   between the primary and secondary population frequency data.
#Accepts:
#   dict prim_af_dict: A dictionary with chromosomes as keys and numpy arrays of allele frequencies for the primary population as values.
#   dict sec_af_dict: A dictionary with chromosomes as keys and numpy arrays of allele frequencies for the secondary population as values.
#   dict pos_dict: Dict populated with keys being chromosomes and values being list of genomic positions
#Returns:
#   float sum_af_RAB: The sum of allele frequency products for the given sites across the populations.
def sum_af(prim_af_dict, sec_af_dict, pos_dict):
    sum_af_RAB = 0

    for chrom in pos_dict:
        for site in pos_dict[chrom]:
            sum_af_RAB += (prim_af_dict[chrom][site] * (1 - sec_af_dict[chrom][site]))

    return sum_af_RAB


#Description:
#   This function computes the ratio of products of allele frequency sums between two populations.
#   It handles cases where the sums might lead to a division by zero or result in NaN.
#Accepts:
#   float sum_X1: Sum of allele frequencies for population A at sites 1.
#   float sum_X2: Sum of allele frequencies for population A at sites 2.
#   float sum_Y1: Sum of allele frequencies for population B at sites 1.
#   float sum_Y2: Sum of allele frequencies for population B at sites 2.
#Returns:
#   float value: The calculated ratio R_AB. Returns None if the result is NaN or division by zero occurs.
def R_AB(sum_X1, sum_X2, sum_Y1, sum_Y2):
    try:
        value = (sum_X1 / sum_X2) * (sum_Y2 / sum_Y1)
        if not math.isnan(value):
            return value
        else:
            raise ValueError("Calculation resulted in NaN. Check the input values for errors.")
    except ZeroDivisionError:
        print("Error: Division by zero encountered in R_AB calculation.")
        return None
