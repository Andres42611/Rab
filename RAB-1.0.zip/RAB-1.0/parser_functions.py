import argparse

def create_parser():
    parser = argparse.ArgumentParser(description='Calculate the R(A,B) ratio')

    # Files and mandatory inputs
    parser.add_argument('-v', '--vcf', type=str, required=True, metavar='VCF_FILE', help='Reference genomic VCF file')
    parser.add_argument('-1', '--site1', type=str, required=True, metavar='SITE1_FILE', help='Sites 1 file with chr # in column 1 and pos # in column 2')
    parser.add_argument('-2', '--site2', type=str, required=True, metavar='SITE2_FILE', help='Sites 2 file with chr # in column 1 and pos # in column 2')
    parser.add_argument('-A', '--popA', type=str, required=True, metavar='POP_A_FILE', help='Subpopulation A file with sample ID in column1 and subpop ID(A) in column 2')
    parser.add_argument('-B', '--popB', type=str, required=True, metavar='POP_B_FILE', help='Subpopulation B file with sample ID in column 1 and subpop ID(B) in column 2')

    # Optional inputs with default values
    parser.add_argument('-f', '--per', type=int, default=20, metavar='PERCENTAGE', help='Percentage to be removed during jackknife sampling [default: 20]')
    parser.add_argument('-n', '--iter', type=int, default=99, metavar='ITERATIONS', help='Number of iterations for sampling [default: 99]')
    parser.add_argument('-c', '--conf', type=int, default=95, metavar='CONFIDENCE', help='Confidence interval for data distribution[default: 95]')
    parser.add_argument('-o', '--out', type=str, default='all', metavar='OUTPUT', help=("Output type (lowercase):"
                                                                                       "'jack' - jackknife plot,"
                                                                                       "'boot' - bootstrap plot,"
                                                                                       "'pv' - R(A/B) point value,"
                                                                                       "'allg' - all plots,"
                                                                                       "'pvj' - point value and jackknife plot,"
                                                                                       "'pvb' - point value and bootstrap plot,"
                                                                                       "'all' - (default) all outputs"))
    parser.add_argument('-af', '--afarr', type=str, default=None, metavar='AFARR_FILE', help='Path to a saved allele frequency array file from previous runs. '
                                                                                        'Use this to speed up computations when only changing sites.')
    
    # Kinship matrix arguments
    parser.add_argument('-Akm', '--Akinmatrix', type=str, metavar='POP_A_KIN_MATRIX', help='Path to .king file containing kinship matrix (popA exclusive)')
    parser.add_argument('-Bkm', '--Bkinmatrix', type=str, metavar='POP_B_KIN_MATRIX', help='Path to .king file containing kinship matrix (popB exclusive)')
    parser.add_argument('-Akid', '--Akinid', type=str, metavar='POP_A_KIN_ID', help='Path to .king file containing IDs for kinship matrix (popA exclusive)')
    parser.add_argument('-Bkid', '--Bkinid', type=str, metavar='POP_B_KIN_ID', help='Path to .king file containing IDs for kinship matrix (popB exclusive)')

    return parser

