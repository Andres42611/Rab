#!/usr/bin/env python3
#Rab Program Source Code
#Author: Andres del Castillo, UG Researcher, Szpiech Lab, The Pennsylvania State University, 2024
#Description: Rab is a matrix-based genomic algorithm designed to quantify the ratio of derived allele frequencies between two populations via VCF file parsing


import os
import sys
import numpy
import allel
import argparse
import warnings
import numpy.linalg as la
warnings.filterwarnings("ignore", category = RuntimeWarning)
numpy.warnings.filterwarnings('ignore', category=numpy.VisibleDeprecationWarning) 
from parser_functions import create_parser, process_site_file, process_population_file
from computation_functions import chrom_dict, af_arr, align_af_arrays, sum_af, R_AB
from samplingstat_functions import stats
from visualization import plot_histogram, save_af_arrays, read_af_arrays

def main():
    parsed = create_parser()
    args = parsed.parse_args()

    refchrom_dict, indicator, vcf_samples = chrom_dict(args.vcf)

    sites_1, sites_2 = {}, {}
    popA, popB = [],[]

    process_site_file(args.site1, refchrom_dict)
    process_site_file(args.site2, refchrom_dict)
    process_population_file(args.popA, vcf_samples)
    process_population_file(args.popB, vcf_samples)

    sites_1chr, sites_2chr = sites_1.keys(), sites_2.keys()

    popA_af_s1 = af_arr(sites_1chr, popA, args.Akinid, args.Akinmatrix, indicator, args.vcf)
    popA_af_s2 = af_arr(sites_2chr, popA, args.Akinid, args.Akinmatrix, indicator, args.vcf)
    popB_af_s1 = af_arr(sites_1chr, popB, args.Bkinid, args.Bkinmatrix, indicator, args.vcf)
    popB_af_s2 = af_arr(sites_2chr, popB, args.Bkinid, args.Bkinmatrix, indicator, args.vcf)

    Aaf_s1 = align_af_arrays(popA_af_s1, refchrom_dict)
    Aaf_s2 = align_af_arrays(popA_af_s2, refchrom_dict)
    Baf_s1 = align_af_arrays(popB_af_s1, refchrom_dict)
    Baf_s2 = align_af_arrays(popB_af_s2, refchrom_dict)

    sum_A1 = sum_af(Aaf_s1, Baf_s1, sites_1)
    sum_A2 = sum_af(Aaf_s2, Baf_s2, sites_2)
    sum_B1 = sum_af(Baf_s1, Aaf_s1, sites_1)
    sum_B2 = sum_af(Baf_s2, Aaf_s2, sites_2)
    statval = R_AB(sum_A1, sum_A2, sum_B1, sum_B2)
    pv = f'The value of R_(A,B) is: {round(statval, 6)}'

    # Perform statistical calculations based on user input
    if args.out in ['pvj', 'jack', 'all', 'allg']:
        Jack_fin_st = stats(sites_1, sites_2, Aaf_s1, Baf_s1, Aaf_s2, Baf_s2, args.per, args.iter, args.conf, False)
        Boot_fin_st = None
    if args.out in ['pvb', 'boot', 'all', 'allg']:
        Boot_fin_st = stats(sites_1, sites_2, Aaf_s1, Baf_s1, Aaf_s2, Baf_s2, args.per, args.iter, args.conf, True)
        Jack_fin_st = None

    output_types = {
        'pv': [pv],
        'jack': [Jack_fin_st],
        'boot': [Boot_fin_st],
        'pvj': [pv, Jack_fin_st],
        'pvb': [pv, Boot_fin_st],
        'allg': [Jack_fin_st, Boot_fin_st],
        'all': [pv, Jack_fin_st, Boot_fin_st]
    }
    
    if args.out in output_types:
        for item in output_types[args.out]:
            print(item)
    else:
        print("Invalid output type")
        sys.exit()

if __name__ == '__main__':
    main()