import matplotlib.pyplot as plt
import numpy
import scipy.stats as st

def plot_histogram(data, title_str):
    n, bins, patches = plt.hist(data, bins='auto', density=True, 
                                color='#0504aa', alpha=0.7, rwidth=0.85)
    plt.grid(axis='y', alpha=0.75)
    
    mn, mx = plt.xlim()
    plt.xlim(mn, mx)
    maxfreq = n.max()
    plt.ylim(ymax=numpy.ceil(maxfreq / 10) * 10 if maxfreq % 10 else maxfreq + 10)

    plt.ylabel("Frequency", fontsize=10, fontweight='bold')
    plt.xlabel("R(A/B) Value", fontsize=10, fontweight='bold')
    plt.title(title_str + " Estimates of R(A/B)", fontsize=14, fontweight='bold')

    # Save the plot with a filename based on the title string
    plt.savefig(f'./{title_str}_histogram.png')


#Description:
#   This function takes a dictionary of aligned allele frequency arrays and writes them to a file.
#   Each line in the file represents a chromosome and its corresponding allele frequencies.
#Accepts:
#   dict pop_dict: A dictionary with chromosomes as keys and aligned allele frequency arrays as values.
#   str filepath: The path to the file where the data should be saved.
def save_af_arrays(pop_dict, filepath):
    with open(filepath, 'w') as file:
        for chrom, af_array in pop_dict.items():
            # Convert the numpy array to a string representation
            af_str = numpy.array2string(af_array, separator=',', max_line_width=numpy.inf)[1:-1]
            # Write the chromosome and its allele frequencies to the file
            file.write(f"{chrom}:{af_str}\n")

#Description:
#   This function parses a text file containing allele frequency data for each chromosome
#   and reconstructs the dictionary with numpy arrays as values to output the equivalen of 'align_af_arrays'
#Accepts:
#   str filepath: Path to the file containing saved allele frequency arrays.
#Returns:
#   dict pop_dict: Dictionary with chromosomes as keys and numpy arrays of allele frequencies as values
def read_af_arrays(filepath):
    pop_dict = {}
    with open(filepath, 'r') as file:
        for line in file:
            parts = line.strip().split(':')
            chrom = parts[0]
            # Convert the string of frequencies back to a numpy array
            af_str = parts[1]
            af_array = numpy.fromstring(af_str, sep=',')
            pop_dict[chrom] = af_array

    return pop_dict