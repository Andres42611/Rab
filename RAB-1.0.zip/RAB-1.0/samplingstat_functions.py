import numpy as np
import random
from computation_functions import sum_af, R_AB

def stats(site1_dict, site2_dict, primpop1, secpop1, primpop2, secpop2, F, N, conf, boot):
    # Initialize an array to store the R_AB ratio estimates for each iteration
    Rab_est = np.empty(N)

    # Loop over N iterations for bootstrap or jackknife sampling
    for i in range(N):
        # Dictionaries to hold the sampled sites for each population
        sampled_pos_dict1 = {}
        sampled_pos_dict2 = {}

        # Iterate over each chromosome in the first dataset
        for chrom, sites in site1_dict.items():
            # Calculate the number of sites to sample based on the percentage F
            num_sites_to_sample = round(len(sites) * (F / 100))
            # Perform sampling with or without replacement based on the 'boot' flag
            sampled_sites = np.random.choice(sites, size=num_sites_to_sample, replace=boot)
            # Store the sampled sites for this chromosome
            sampled_pos_dict1[chrom] = sampled_sites

        # Repeat the sampling process for the second dataset
        for chrom, sites in site2_dict.items():
            num_sites_to_sample = round(len(sites) * (F / 100))
            sampled_sites = np.random.choice(sites, size=num_sites_to_sample, replace=boot)
            sampled_pos_dict2[chrom] = sampled_sites

        # Calculate the sum of allele frequency products for the sampled positions
        sum_A1 = sum_af(primpop1, secpop1, sampled_pos_dict1)
        sum_A2 = sum_af(primpop2, secpop2, sampled_pos_dict2)
        sum_B1 = sum_af(secpop1, primpop1, sampled_pos_dict1)
        sum_B2 = sum_af(secpop2, primpop2, sampled_pos_dict2)
        # Compute the R_AB ratio using the sums from both datasets
        Rab_est[i] = R_AB(sum_A1, sum_A2, sum_B1, sum_B2)

    # Calculate the mean and standard deviation of the estimated R_AB ratios
    Est_mean = round(np.mean(Rab_est), 6)

    # Compute the confidence interval for the R_AB estimates using the empirical method
    lower_percentile = (100 - conf) / 2
    upper_percentile = 100 - lower_percentile
    ci_lower = np.percentile(Rab_est, lower_percentile)
    ci_upper = np.percentile(Rab_est, upper_percentile)

    # Create a summary string to report the results
    title_str = 'Bootstrap Sampling' if boot else 'Jackknife Sampling'
    summary = (f'The mean R(A,B) value is {Est_mean:.6f} via {title_str}. \n'
               f'With {conf}% confidence, the expected value of R(A/B) between both populations lies '
               f'between {ci_lower:.6f} and {ci_upper:.6f} via {title_str}.')

    # Return the summary of the results
    return summary